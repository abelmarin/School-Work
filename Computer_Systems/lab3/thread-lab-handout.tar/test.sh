#!/bin/bash
UDS_PATH="udslogger"
./test-messages $UDS_PATH
