#!/bin/bash
UDS_PATH="udslogger"
./stop-loggerd $UDS_PATH
