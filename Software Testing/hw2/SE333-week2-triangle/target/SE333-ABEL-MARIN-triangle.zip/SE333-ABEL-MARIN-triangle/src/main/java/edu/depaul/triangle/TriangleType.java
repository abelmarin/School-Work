package edu.depaul.triangle;

/**
 * Names of triangle types
 */
public enum TriangleType {
  EQUILATERAL,
  ISOSCELES,
  SCALENE
}
