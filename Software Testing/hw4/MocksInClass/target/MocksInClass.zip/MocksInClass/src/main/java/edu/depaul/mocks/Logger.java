package edu.depaul.mocks;

public interface Logger {
	
	public void log(String msg);

}
