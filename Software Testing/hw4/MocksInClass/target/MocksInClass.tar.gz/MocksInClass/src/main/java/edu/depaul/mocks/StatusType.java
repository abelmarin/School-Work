package edu.depaul.mocks;

public enum StatusType {OK, INTERNAL_ERROR, UNKNOWN_OPERATION};
